import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-empleado',
  templateUrl: './nav-empleado.component.html',
  styleUrls: ['./nav-empleado.component.css']
})
export class NavEmpleadoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
